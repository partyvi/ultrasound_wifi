 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\34\\53\\3453882\\2\Altium\2019-07-31_20-05-50\2019-07-31_20-05-50
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D00"
Padstack "RX118p11Y118p11D0T" renamed to "RX118p11Y118p11D"
Symbol "WB_LM46002_CFF_BLOCK" renamed to "WB_LM46002_CFF_B"
Symbol "WB_LM46002_EN_WIRE" renamed to "WB_LM46002_EN_WI"
Symbol "WB_ZERO_VOLT_SOURCE" renamed to "WB_ZERO_VOLT_SOU"
Symbol "WB_LM46002_RT_BLOCK" renamed to "WB_LM46002_RT_BL"
Symbol "WB_LM46002_CSS_BLOCK" renamed to "WB_LM46002_CSS_B"
Symbol "WB_PRIMITIVE_CAPACITOR" renamed to "WB_PRIMITIVE_CAP"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Component "ME3220-273KLB" renamed to "ME3220-273KLB"
Component "GRM155R60J474KE19D" renamed to "GRM155R60J474KE1"
Component "CRCW040273K2FKED" renamed to "CRCW040273K2FKED"
Component "LM43601PWPR" renamed to "LM43601PWPR"
Component "GRM1555C1H161JA01D" renamed to "GRM1555C1H161JA0"
Component "EEE-FK1A330UR" renamed to "EEE-FK1A330UR"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "CRCW04021M00FKED" renamed to "CRCW04021M00FKED"
Component "CRCW040229K4FKED" renamed to "CRCW040229K4FKED"
Component "CRCW0402100KFKED" renamed to "CRCW0402100KFKED"
Component "EMK212BJ225KG-T" renamed to "EMK212BJ225KG-T"
Component "C1608X5R1V475K080AC" renamed to "C1608X5R1V475K08"
Component "WB_GND" renamed to "WB_GND"
Component "TMK212BJ475KG-T" renamed to "TMK212BJ475KG-T"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "CL32B106KBJNNWE" renamed to "CL32B106KBJNNWE"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM43601PWP was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM43601PWP was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM43601PWP was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_CFF_B was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_CFF_B was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_CFF_B was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_EN_WI was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_EN_WI was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_EN_WI was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_RT_BL was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_RT_BL was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_RT_BL was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_RPG1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_RPG1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_RPG1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_CSS_B was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_CSS_B was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_CSS_B was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM46002_BIAS1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM46002_BIAS1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM46002_BIAS1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Pattern "ME3220", entity (118-Line) is a LINE with matching start and end points.
Message - Pattern "ME3220", entity (120-Line) is a LINE with matching start and end points.
Message - Pattern "ME3220", entity (122-Line) is a LINE with matching start and end points.
Message - Pattern "ME3220", entity (124-Line) is a LINE with matching start and end points.
Message - Component "ME3220-273KLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ME3220-273KLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ME3220-273KLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J474KE1" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J474KE1" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J474KE1" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J474KE1" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040273K2FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040273K2FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040273K2FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM43601PWPR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H161JA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H161JA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H161JA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H161JA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEE-FK1A330UR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEE-FK1A330UR" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEE-FK1A330UR" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEE-FK1A330UR" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEE-FK1A330UR" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M00FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M00FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M00FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040229K4FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212BJ225KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212BJ225KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212BJ225KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212BJ225KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1V475K08" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1V475K08" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1V475K08" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1V475K08" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1V475K08" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL32B106KBJNNWE" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL32B106KBJNNWE" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL32B106KBJNNWE" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL32B106KBJNNWE" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL32B106KBJNNWE" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   9
Pattern count:    7
Symbol count:     29
Component count:  16

Export

Footprint "ME3220" has no layer data mapped and will be skipped.
Component "ME3220-273KLB" requires footprint "ME3220" and will be skipped.
Footprint "0402" has no layer data mapped and will be skipped.
Component "GRM155R60J474KE1" requires footprint "0402" and will be skipped.
Component "CRCW040273K2FKED" requires footprint "0402" and will be skipped.
Component "GRM1555C1H161JA0" requires footprint "0402" and will be skipped.
Component "CRCW04021M00FKED" requires footprint "0402" and will be skipped.
Component "CRCW040229K4FKED" requires footprint "0402" and will be skipped.
Component "CRCW0402100KFKED" requires footprint "0402" and will be skipped.
Footprint "0603" has no layer data mapped and will be skipped.
Component "C1608X5R1V475K08" requires footprint "0603" and will be skipped.
Footprint "0805" has no layer data mapped and will be skipped.
Component "EMK212BJ225KG-T" requires footprint "0805" and will be skipped.
Component "TMK212BJ475KG-T" requires footprint "0805" and will be skipped.
Warning: Symbol "LM43601PWP" attribute "PN" references missing text style ""
Warning: Symbol "LM43601PWP" attribute "DEV" references missing text style ""
Warning: Symbol "LM43601PWP" attribute "VAL" references missing text style ""
Warning: Symbol "LM43601PWP" attribute "TOL" references missing text style ""
Warning: Symbol "LM43601PWP" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
